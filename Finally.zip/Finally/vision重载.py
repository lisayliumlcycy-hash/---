import importlib
import vision  # 确保先导入模块本身

def reload_vision():
    # 1. 强制重新加载模块文件
    importlib.reload(vision)
    
    # 2. 将更新后的函数/变量重新映射到全局命名空间
    # 注意：这里需要包含你 main 函数中用到的所有来自 vision 的变量
    global get_position_from_image, width, height
    from vision import get_position_from_image, width, height
    
    print("✅ vision.py 已成功重载！新的参数已生效。")

# 每次修改完文件，执行一次这个函数即可
reload_vision()