import time
import random

def victory_celebration():
    # 胜利奖杯的 ASCII 艺术
    trophy = """
           ___________
          '._==_==_=_.'
          .-:      :-.
         | (|:.     |) |
          '-|:.     |-'
            \\::.    /
             '::. .'
               ) (
             _.' '._
            `-------`
    """
    
    messages = [
        "绝佳的杀招！",
        "Stockfish 也会为你感到自豪！",
        "这一局下得太精彩了！",
        "将军！比赛结束！",
        "完美的战术转换！"
    ]

    print("\033[1;33m" + trophy + "\033[0m") # 金色奖杯
    print("\n" + "="*40)
    print(f"🎉 {random.choice(messages)} 🎉")
    print("="*40 + "\n")

    # 模拟动态烟花效果
    colors = ['\033[91m', '\033[92m', '\033[93m', '\033[94m', '\033[95m', '\033[96m']
    try:
        print("正在释放胜利烟花（按 Ctrl+C 停止）...")
        while True:
            space = " " * random.randint(0, 50)
            firework = random.choice(["*", "o", "O", "✨", "💥"])
            color = random.choice(colors)
            print(f"{space}{color}{firework}\033[0m")
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("\n\n庆祝结束！准备好开始下一局了吗？")

if __name__ == "__main__":
    victory_celebration()