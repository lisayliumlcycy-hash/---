from enum import Enum
from collections import namedtuple
import cv2
import numpy as np

# --- 1. CONFIGURATION (保持小写变量名) ---

width, height = 320, 240

# 🎯 固化的准确阈值
white_thresh = 110
black_thresh = 150 
default_cut_margin = 0 

# 颜色常量 (黄色背景检测)
yellow_lower = (21, 147, 111)  
yellow_upper = (41, 255, 255)  

# 棋盘角点颜色掩码 (Red, Green, Blue, Purple)
CORNER_MASKS_HSV = [
    ((0, 140, 102), (15, 255, 255)),    # 0: 红色
    ((62, 75, 50), (82, 255, 255)),     # 1: 绿色
    ((96, 140, 95), (116, 255, 255)),   # 2: 蓝色
    ((125, 50, 50), (145, 255, 255)),   # 3: 紫色
]

# --- 2. BASE CLASSES ---

Point = namedtuple("Point", ["x", "y"])

class SquareType(Enum):
    empty = 0
    white = 1
    black = 2

    def __str__(self):
        if self == SquareType.empty: return ' '
        if self == SquareType.white: return 'o'
        if self == SquareType.black: return 'x'
        return ''

class ChessboardNotFoundError(Exception):
    """当无法找到棋盘角点时引发此异常"""
    pass

# --- 3. HELPER FUNCTIONS ---

def _clean_mask(mask, kernel_size=(5, 5)):
    kernel = np.ones(kernel_size, np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel) 
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    return mask

def _threshold_image(image):
    blurred = cv2.blur(image, (10, 10))
    _, thresholded = cv2.threshold(blurred, 200, 255, cv2.THRESH_BINARY)
    return thresholded

def _find_point(image):
    def center(contour):
        x, y, w, h = cv2.boundingRect(contour)
        return Point(x + w // 2, y + h // 2)
    contours, _ = cv2.findContours(image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if len(contours) < 1:
        return None
    contour = max(contours, key=cv2.contourArea)
    return center(contour)

def find_corners(image):
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    masks = [cv2.inRange(hsv, lower, upper) for lower, upper in CORNER_MASKS_HSV]
    points = [_find_point(_threshold_image(_clean_mask(mask))) for mask in masks]

    if not all(points):
        return None

    x0, y0 = points[0]
    x1, y1 = points[1]
    x2, y2 = points[2]
    x3, y3 = points[3]

    # 应用微调公式
    adjusted_points = [
        Point(int(x0 + (x0 - x1) * 0.00 - (x0 - x2) * 0.05), int(y0 + (y0 - y1) * 0.00 - (y0 - y2) * 0.05)),
        Point(int(x1 + (x1 - x0) * 0.08 - (x1 - x3) * 0.05), int(y1 + (y1 - y0) * 0.08 - (y1 - y3) * 0.05)), 
        Point(int(x2 + (x2 - x3) * 0.02 - (x2 - x0) * 0.05), int(y2 + (y2 - y3) * 0.02 - (y2 - y0) * 0.05)),
        Point(int(x3 + (x3 - x2) * 0.08 - (x3 - x1) * 0.05), int(y3 + (y3 - y2) * 0.08 - (y3 - y1) * 0.05)),
    ]
    return adjusted_points

def transform(image, corners):
    src = np.array([(p.x, p.y) for p in corners], np.float32)
    dst = np.array([(0, 0), (width, 0), (0, height), (width, height)], np.float32)
    matrix = cv2.getPerspectiveTransform(src, dst)
    return cv2.warpPerspective(image, matrix, (width, height))

def detect_square_type(roi_gray, roi_hsv):
    """
    核心检测逻辑：
    1. 优先使用 HSV 颜色检测黄色背景 (empty)
    2. 若非黄色，根据亮度阈值区分黑白棋子
    """
    # 1. 颜色过滤检测空位 (黄色背景)
    yellow_mask = cv2.inRange(roi_hsv, yellow_lower, yellow_upper)
    yellow_ratio = cv2.countNonZero(yellow_mask) / roi_gray.size
    
    if yellow_ratio > 0.50: 
        return SquareType.empty
    
    # 2. 亮度阈值区分棋子
    mean_val = np.mean(roi_gray) 
    
    if mean_val > white_thresh: 
        return SquareType.white
    elif mean_val < black_thresh:
        return SquareType.black
    else:
        return SquareType.empty

# --- 4. MAIN INTERFACE ---

def get_position_from_image(image):
    """
    识别图像中的棋盘，并返回对应的 8x8 SquareType 阵列和矫正后的图像。
    """
    # 1. 缩放输入图像
    img_work = cv2.resize(image, (width, height))
    
    # 2. 寻找角点并变换
    corners = find_corners(img_work)
    if corners is None:
        raise ChessboardNotFoundError("未检测到完整的棋盘标记点")

    chessboard_image = transform(img_work, corners)
    
    # 3. 预处理颜色空间
    chessboard_gray = cv2.cvtColor(chessboard_image, cv2.COLOR_BGR2GRAY)
    chessboard_hsv = cv2.cvtColor(chessboard_image, cv2.COLOR_BGR2HSV)
    
    sq_w, sq_h = width // 8, height // 8
    position = []
    
    # 4. 遍历 8x8 棋格
    for j in range(8):
        row = []
        for i in range(8):
            # 定义切片区域 (取每个格子的中心 ROI 避免边缘干扰)
            y_start, y_end = j * sq_h, (j + 1) * sq_h
            x_start, x_end = i * sq_w, (i + 1) * sq_w
            
            # ROI 截取中心 40%
            roi_g = chessboard_gray[int(y_start + sq_h*0.3):int(y_start + sq_h*0.7), 
                                    int(x_start + sq_w*0.3):int(x_start + sq_w*0.7)]
            roi_h = chessboard_hsv[int(y_start + sq_h*0.3):int(y_start + sq_h*0.7), 
                                   int(x_start + sq_w*0.3):int(x_start + sq_w*0.7)]
            
            square_type = detect_square_type(roi_g, roi_h)
            row.append(square_type)
        position.append(row)

    return position, chessboard_image